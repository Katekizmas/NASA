﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace NASA
{
    public partial class MokejimoForma : Form
    {
        static int id;
        static string busena;
        public MokejimoForma()
        {
            InitializeComponent();
            /*
            this.label3.Text = "Aikštelė :"
            this.label4.Text = "Automobilio numeris :";
            this.label5.Text = "Stovėjimo pradžia :";
            this.label6.Text = "Stovėjimo pabaiga :";*/

        }
        public void getInfo()
        {
            Database db = new Database();
            db.sqlConnect.Open();


            string query;
            query = string.Format("SELECT Semestras_Stovejimo_laikas.stovejimo_pradzia as st_pradzia, " +
                            "Semestras_Stovejimo_laikas.stovejimo_pabaiga as st_pabaiga, " +
                            "Semestras_Stovejimo_laikas.Kodas as st_kodas, " +
                            "Semestras_Stovejimo_laikas.Busena as st_busena, " +
                            "Semestras_Stovejimo_laikas.id_Stovejimo_laikas as st_id, " +
                            "Semestras_Transporto_priemone.Numeris as tr_numeris, " +
                            "Semestras_Kaina.Kaina as kaina, " +
                            "Semestras_Aikstele.Adresas as pad_adresas " +
                            "FROM Semestras_Stovejimo_laikas " +
                            "INNER JOIN Semestras_Transporto_priemone ON Semestras_Stovejimo_laikas.fk_Transporto_priemone = Semestras_Transporto_priemone.id_Transporto_priemone " +
                            "INNER JOIN Semestras_Aikstele ON Semestras_Transporto_priemone.fk_Aikstele = Semestras_Aikstele.id_Aikstele " +
                            "INNER JOIN Semestras_Kaina ON Semestras_Aikstele.fk_Kaina = Semestras_Kaina.id_Kaina " +
                            "WHERE Semestras_Stovejimo_laikas.Kodas = '{0}'", textBox1.Text);
            MySqlCommand cmd = new MySqlCommand(query, db.sqlConnect);

            MySqlDataReader dataReader = cmd.ExecuteReader();
            //List<string> data = new List<string>();
            while (dataReader.Read())
            {
                DateTime pradzia = DateTime.Parse(dataReader["st_pradzia"].ToString());
                DateTime pabaiga = DateTime.Parse(dataReader["st_pabaiga"].ToString());
                string kodas = dataReader["st_kodas"].ToString();
                busena = dataReader["st_busena"].ToString();
                string kaina = dataReader["kaina"].ToString();
                string numeris = dataReader["tr_numeris"].ToString();
                string aiksteles_adresas = dataReader["pad_adresas"].ToString();
                id = int.Parse(dataReader["st_id"].ToString());
                label8.Text = aiksteles_adresas;
                label9.Text = numeris;
                label10.Text = String.Format("{0:yyyy-MM-dd HH:mm:ss}", pradzia);
                label11.Text = String.Format("{0:yyyy-MM-dd HH:mm:ss}", pabaiga);
                TimeSpan temp = pabaiga - pradzia;
                double kainaviso;
                if (Math.Floor(temp.TotalMinutes) < 15)
                {
                    kainaviso = double.Parse(kaina);
                    label12.Text = kaina + " €";
                }
                else
                {
                    kainaviso = (Math.Floor(temp.TotalMinutes) / 15 + 1) * double.Parse(kaina);
                    label12.Text = kainaviso + " €";
                }
            }
            db.sqlConnect.Close();

        }
        public void UpdateBusena()
        {
            Database db = new Database();
            db.sqlConnect.Open();


            string query;

            query = string.Format("UPDATE `Semestras_Stovejimo_laikas` SET `Busena` = 'Apmoketa' WHERE `Semestras_Stovejimo_laikas`.`id_Stovejimo_laikas` = {0}", id);
            MySqlCommand cmd = new MySqlCommand(query, db.sqlConnect);

            if (busena == "Paruosta")
            {
                MySqlDataReader dataReader = cmd.ExecuteReader();
                MessageBox.Show("Sėkmingai apmokėjote");
                query = string.Format("SELECT Semestras_Stovejimo_laikas.Busena as st_busena " +
                            "FROM Semestras_Stovejimo_laikas " +
                            "WHERE `Semestras_Stovejimo_laikas`.`id_Stovejimo_laikas` = {0}", id);
                while (dataReader.Read())
                {
                    busena = dataReader["st_busena"].ToString();
                }
                busena = "Apmoketa";
            }
            else if (busena == "Apmoketa")
            {
                MessageBox.Show("Jūs jau apmokėjote");
            }
            else
            {
                MessageBox.Show("Jūs vis dar neišvažiavote");
            }
            db.sqlConnect.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string box = textBox1.Text;
            string kodas = textBox1.Text;

            if (arKodasEgzistuoja(box, kodas))
            {
                //
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
                label7.Visible = true;

                //
                getInfo();
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = true;
                label11.Visible = true;
                label12.Visible = true;
            }
            else
            {
                MessageBox.Show("Toks kodas neegzistuoja");
            }
        }
        private static bool arKodasEgzistuoja(string a, string b)
        {
            if (a == b)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateBusena();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

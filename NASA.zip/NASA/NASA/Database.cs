﻿using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;

namespace NASA
{
    public class Database
    {
        //private string connStr;
        public MySqlConnection sqlConnect = new MySqlConnection();
        const string connStr = "SERVER=stud.if.ktu.lt; PORT=3306;DATABASE=domkel; UID=domkel;PASSWORD=queth8eiquo5Dah0;";

        private MySqlCommand cmd;
        private MySqlDataReader dataReader;

        MySqlConnectionStringBuilder conn_string = new MySqlConnectionStringBuilder();

        public Database()
        {
            conn_string.Server = "remotemysql.com";
            conn_string.UserID = "UST4tbdtjQ";
            conn_string.Password = "CMn3WAPDfR";
            conn_string.Database = "UST4tbdtjQ";
            conn_string.Port = 3306;

            sqlConnect.ConnectionString = conn_string.ToString();


        }

        public bool connected()
        {
            if (sqlConnect != null)
            {
                return true;
            }

            return false;
        }

        public void getAikst(DataTable aikstTable, object key)
        {
            sqlConnect.Open();
            aikstTable.Clear();


            string query = "SELECT Semestras_Aikstele.id_Aikstele,Semestras_Aikstele.Adresas,Semestras_Aikstele.Vietu_skaicius,Semestras_Kaina.Kaina " +
                "FROM Semestras_Aikstele " +
                "INNER JOIN Semestras_Kaina ON Semestras_Aikstele.fk_Kaina = Semestras_Kaina.id_Kaina " +
                "WHERE Semestras_Aikstele.fk_Padalinys = " + key.ToString();
            cmd = new MySqlCommand(query, sqlConnect);

            dataReader = cmd.ExecuteReader();
            //List<string> data = new List<string>();
            while (dataReader.Read())
            {

                //data.Add(dataReader["numeris"].ToString());
                string id = dataReader["id_Aikstele"].ToString();
                string adr = dataReader["Adresas"].ToString();
                string vsk = dataReader["Vietu_skaicius"].ToString();
                string kan = dataReader["Kaina"].ToString();
                //string aikstele_viet_sk = dataReader[""].ToString();
                //string stovLaikas = dataReader["fk_Stovejimo_laikas"].ToString();
                aikstTable.Rows.Add(new object[] { id,adr, vsk, kan });
            }
            sqlConnect.Close();

        }
        public void getAuto(DataTable autoTable, object key)
        {
            sqlConnect.Open();
            autoTable.Clear();


            string query = "SELECT Semestras_Transporto_priemone.Numeris, Semestras_Transporto_priemone.Busena " +
                "FROM Semestras_Transporto_priemone " +
                "INNER JOIN Semestras_Aikstele ON Semestras_Aikstele.id_Aikstele = Semestras_Transporto_priemone.fk_Aikstele " +
                "WHERE Semestras_Transporto_priemone.fk_Aikstele = " + key.ToString();

            cmd = new MySqlCommand(query, sqlConnect);

            dataReader = cmd.ExecuteReader();
            //List<string> data = new List<string>();
            while (dataReader.Read())
            {              
                string nr = dataReader["Numeris"].ToString();
                string bs = dataReader["Busena"].ToString();
                              
                autoTable.Rows.Add(new object[] { nr, bs });
            }
            sqlConnect.Close();

        }

        public class ComboboxItem
        {
            public string Text { get; set; }

            public string fullText { get; set; }
            public object Key { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }
        public void getImoneList(ComboBox Imones)
        {
            sqlConnect.Open();
            Imones.Items.Clear();






            string query = "SELECT Semestras_Imone.* " +
                "FROM Semestras_Imone ";

            cmd = new MySqlCommand(query, sqlConnect);

            dataReader = cmd.ExecuteReader();


            while (dataReader.Read())
            {
                ComboboxItem item = new ComboboxItem();
                string pav, viet, adr, pst;
                pav = dataReader["Pavadinimas"].ToString();
                pst = dataReader["EL_Pastas"].ToString();
                viet = dataReader["Gyvenamoji_vietove"].ToString();
                adr = dataReader["Adresas"].ToString();

                item.Text = pav;
                item.Key = pst;
                item.fullText = pav + ", " + viet + ", " + adr + " - " + pst;

                Imones.Items.Add(item);
            }


            sqlConnect.Close();


        }
        public void getPadalinysList(ComboBox Imones, object key)
        {
            sqlConnect.Open();
            Imones.Items.Clear();



            string query = "SELECT Semestras_Padalinys.* " +
                 "FROM Semestras_Padalinys WHERE Semestras_Padalinys.fk_Imone=\"" + key.ToString() + "\"";

            cmd = new MySqlCommand(query, sqlConnect);

            dataReader = cmd.ExecuteReader();

            while (dataReader.Read())
            {
                ComboboxItem item = new ComboboxItem();
                string pav, vad;
                pav = dataReader["Pavadinimas"].ToString();
                vad = dataReader["Vadovas"].ToString();



                item.Text = pav;
                item.Key = dataReader["id_Padalinys"];

                item.fullText = pav + ", vadovas - " + vad;

                Imones.Items.Add(item);


            }

            sqlConnect.Close();


        }
        public void getAiksteleList(ComboBox Imones, object key)
        {
            sqlConnect.Open();
            Imones.Items.Clear();


            string query = "SELECT Semestras_Aikstele.* " +
                "FROM Semestras_Aikstele WHERE Semestras_Aikstele.fk_Padalinys=\"" + key.ToString() + "\"";

            cmd = new MySqlCommand(query, sqlConnect);

            dataReader = cmd.ExecuteReader();
            //List<string> data = new List<string>();
            while (dataReader.Read())
            {
                ComboboxItem item = new ComboboxItem();
                string adr, vsk;
                adr = dataReader["Adresas"].ToString();
                vsk = dataReader["Vietu_skaicius"].ToString();

                item.Text = adr;
                item.Key = dataReader["id_Aikstele"].ToString();
                item.fullText = adr + ", vietų skaičius - " + vsk;
                Imones.Items.Add(item);
            }
            sqlConnect.Close();

        }

    }
}

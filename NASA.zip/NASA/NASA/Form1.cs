﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace NASA
{
    public partial class Form1 : Form
    {
        Database db;
        MokejimoForma mokForma;
        public Form1()
        {
            InitializeComponent();
            db = new Database();
            dataGrid.Hide();
            ImonesList.Hide();
            PadalinysList.Hide();
            //AikstelesList.Hide();
            imoneLabel.Hide();
            imoneLabelText.Hide();
            padalinysLabel.Hide();
            padalinysLabelText.Hide();
            //aiksteleLabel.Hide();
            //aiksteleLabelText.Hide();
            IsMdiContainer = true;

        }




        private void button5_Click(object sender, EventArgs e)
        {
            Settings sett = new Settings();
            sett.Show();
            button5.Enabled = false;

        }

        private void database_Click(object sender, EventArgs e)
        {
            if (mokForma != null)
            {
                mokForma.Close();
            }

            buttonPress.Location = new Point(195, 210);
            defaultPanel.Show();
            //nasaLabel.Hide();
            ImonesList.Show();
            db.getImoneList(ImonesList);
            ImonesList.Text = "-- Pasirinkite įmonę --";

            //ImonesList.DropDownStyle = ComboBoxStyle.DropDownList;
            //ImonesList.DrawMode = DrawMode.OwnerDrawFixed;

        }

        private void userInfo_Click(object sender, EventArgs e)
        {
            buttonPress.Location = new Point(195, 110);

            dataGrid.Hide();
            defaultPanel.Hide();

            ImonesList.Hide();
            PadalinysList.Hide();
            imoneLabel.Hide();
            imoneLabelText.Hide();
            padalinysLabel.Hide();
            padalinysLabelText.Hide();


            if (mokForma == null)
            {
                mokForma = new MokejimoForma();
                mokForma.MdiParent = this;
                mokForma.FormClosed += new FormClosedEventHandler(MokForma_FormClosed);
                mokForma.Show();
            }
            else
            {
                mokForma.Activate();
            }
        }

        private void MokForma_FormClosed(object sender, FormClosedEventArgs e)
        {
            mokForma = null;
            //throw new NotImplementedException();
        }

        private void ImonesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGrid.Hide();
            padalinysLabel.Hide();
            padalinysLabelText.Hide();
            //aiksteleLabel.Hide();
            //aiksteleLabelText.Hide();
            //AikstelesList.Hide();
            PadalinysList.Text = "-- Pasirinkite padalinį --";

            imoneLabel.Show();
            imoneLabelText.Text = (ImonesList.SelectedItem as Database.ComboboxItem).fullText;
            imoneLabelText.Show();

            PadalinysList.Show();
            object key = (ImonesList.SelectedItem as Database.ComboboxItem).Value;


            db.getPadalinysList(PadalinysList, key);
        }

        private void PadalinysList_SelectedIndexChanged(object sender, EventArgs e)
        {
            //AikstelesList.Hide();
            //AikstelesList.Text= "-- Pasirinkite aikštelę --";

            padalinysLabel.Show();
            padalinysLabelText.Text = (PadalinysList.SelectedItem as Database.ComboboxItem).fullText;
            padalinysLabelText.Show();

            //AikstelesList.Show();
            object key = (PadalinysList.SelectedItem as Database.ComboboxItem).Value;

            //db.getAiksteleList(AikstelesList,key);

            dataGrid.Show();
            DataTable dataTable_Aikst = new DataTable();



            dataTable_Aikst.Columns.Add("ADRESAS");
            dataTable_Aikst.Columns.Add("VIETŲ SKAIČIUS");
            dataTable_Aikst.Columns.Add("KAINA");
            //dataTable_Aikst.Columns.Add("Vietu skaicius");
            dataGrid.DataSource = dataTable_Aikst;

            db.getAikst(dataTable_Aikst, key);
        }


        private void AikstelesList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            buttonPress.Location = new Point(195, 310);
            nasaLabel.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            buttonPress.Location = new Point(195, 410);
        }
    }
}

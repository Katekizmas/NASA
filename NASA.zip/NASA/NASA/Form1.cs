﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace NASA
{
    public partial class Form1 : Form
    {
        Database db;
        MokejimoForma mokForma;
        public Form1()
        {
            InitializeComponent();
            db = new Database();
            dataGrid_Aikst.Hide();
            dataGrid_Auto.Hide();
            ImonesList.Hide();
            PadalinysList.Hide();
            imoneLabel.Hide();
            imoneLabelText.Hide();
            padalinysLabel.Hide();
            padalinysLabelText.Hide();
            aikstEmptyLabel.Hide();
            aikstEmptyLabel2.Hide();

            dataGrid_Aikst.Size = new Size(1080, dataGrid_Aikst.Height);

            IsMdiContainer = true;

        }




        private void button5_Click(object sender, EventArgs e)
        {
            Settings sett = new Settings();
            sett.Show();
            button5.Enabled = false;

        }

        private void database_Click(object sender, EventArgs e)
        {
            if (mokForma != null)
            {
                mokForma.Close();
            }

            buttonPress.Location = new Point(195, 210);
            dataGrid_Aikst.Size = new Size(1080, dataGrid_Aikst.Height);
            dataGrid_Auto.Hide();
            aikstEmptyLabel.Hide();
            aikstEmptyLabel2.Hide();
            defaultPanel.Show();
            nasaLabel.Show();
            ImonesList.Show();
            db.getImoneList(ImonesList);
            ImonesList.Text = "-- Pasirinkite įmonę --";

            //ImonesList.DropDownStyle = ComboBoxStyle.DropDownList;
            //ImonesList.DrawMode = DrawMode.OwnerDrawFixed;

        }

        private void userInfo_Click(object sender, EventArgs e)
        {
            buttonPress.Location = new Point(195, 110);

            dataGrid_Aikst.Hide();
            dataGrid_Auto.Hide();
            defaultPanel.Hide();

            ImonesList.Hide();
            PadalinysList.Hide();
            imoneLabel.Hide();
            imoneLabelText.Hide();
            padalinysLabel.Hide();
            padalinysLabelText.Hide();
            aikstEmptyLabel.Hide();
            aikstEmptyLabel2.Hide();


            if (mokForma == null)
            {
                mokForma = new MokejimoForma();
                mokForma.MdiParent = this;
                mokForma.FormClosed += new FormClosedEventHandler(MokForma_FormClosed);
                mokForma.Show();
            }
            else
            {
                mokForma.Activate();
            }
        }

        private void MokForma_FormClosed(object sender, FormClosedEventArgs e)
        {
            mokForma = null;
            //throw new NotImplementedException();
        }

        private void ImonesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGrid_Auto.Hide();
            dataGrid_Aikst.Hide();
            padalinysLabel.Hide();
            padalinysLabelText.Hide();
            nasaLabel.Show();

            PadalinysList.Text = "-- Pasirinkite padalinį --";

            imoneLabel.Show();
            imoneLabelText.Text = (ImonesList.SelectedItem as Database.ComboboxItem).fullText;
            imoneLabelText.Show();

            PadalinysList.Show();
            object key = (ImonesList.SelectedItem as Database.ComboboxItem).Key;


            db.getPadalinysList(PadalinysList, key);
        }

        private void PadalinysList_SelectedIndexChanged(object sender, EventArgs e)
        {

            aikstEmptyLabel.Hide();
            aikstEmptyLabel2.Hide();
            dataGrid_Auto.Hide();

            padalinysLabel.Show();
            padalinysLabelText.Text = (PadalinysList.SelectedItem as Database.ComboboxItem).fullText;
            padalinysLabelText.Show();


            object key = (PadalinysList.SelectedItem as Database.ComboboxItem).Key;


            nasaLabel.Hide();

            dataGrid_Aikst.Show();
            DataTable dataTable_Aikst = new DataTable();


            dataTable_Aikst.Columns.Add("ID");
            dataTable_Aikst.Columns.Add("ADRESAS");
            dataTable_Aikst.Columns.Add("VIETŲ SKAIČIUS");
            dataTable_Aikst.Columns.Add("KAINA");
            dataGrid_Aikst.DataSource = dataTable_Aikst;
            dataGrid_Aikst.Columns["ID"].Visible = false;
            db.getAikst(dataTable_Aikst, key);
        }


        private void AikstelesList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            buttonPress.Location = new Point(195, 310);
            nasaLabel.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            buttonPress.Location = new Point(195, 410);
        }

        private void dataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataTable dataTable_Auto = new DataTable();


            dataTable_Auto.Columns.Add("NUMERIS");
            dataTable_Auto.Columns.Add("BŪSENA");
            dataGrid_Auto.DataSource = dataTable_Auto;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGrid_Aikst.Rows[e.RowIndex];

                object key = row.Cells["ID"].Value.ToString();

                dataGrid_Aikst.Size = new Size(510, dataGrid_Aikst.Height);
                db.getAuto(dataTable_Auto, key);

                if (dataTable_Auto.Rows.Count > 0)
                {
                    dataGrid_Auto.Show();
                    aikstEmptyLabel.Hide();
                    aikstEmptyLabel2.Hide();
                }

                else
                {
                    dataGrid_Auto.Hide();
                    string aikstele = row.Cells["ADRESAS"].Value.ToString();
                    aikstEmptyLabel.Text = aikstele + " aikst.";
                    aikstEmptyLabel.Show();
                    aikstEmptyLabel2.Show();

                }

            }
        }

        private void dataGrid_Auto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace NASA
{
    public partial class Statistics : Form
    {
        DateTime currTime;
        DateTime fromTime;
        string query;
        const string defaultQuery = "SELECT COUNT(Semestras_Stovejimo_laikas.id_Stovejimo_laikas) AS Kiekis, " +
               "DATE_FORMAT(ANY_VALUE(Semestras_Stovejimo_laikas.stovejimo_pradzia),\"%Y-%m-%d\") AS Laikas " +
               "FROM Semestras_Stovejimo_laikas GROUP BY laikas ORDER BY laikas ASC";


        public Statistics()
        {
            
            InitializeComponent();

            currTime = DateTime.Now;

            button_All.BackColor = Color.White;           
            CreateChart(defaultQuery);

            
        }

        private void button_1h_Click(object sender, EventArgs e)
        {
            ButtonColorChange(button_1h);

            this.statChart.ChartAreas[0].AxisX.LabelStyle.Format = "HH:mm";
            fromTime = currTime.Add(new TimeSpan(-1, 0, 0));

            query = String.Format("SELECT COUNT(Semestras_Stovejimo_laikas.id_Stovejimo_laikas) AS Kiekis, DATE_FORMAT(ANY_VALUE(Semestras_Stovejimo_laikas.stovejimo_pradzia), \"%y-%m-%d %h:%m\") AS laikas " +
                "FROM Semestras_Stovejimo_laikas " +
                "WHERE Semestras_Stovejimo_laikas.stovejimo_pradzia >= \"{0:yyyy-MM-dd HH:mm:ss}\" AND " +
                "Semestras_Stovejimo_laikas.stovejimo_pradzia <= \"{1:yyyy-MM-dd HH:mm:ss}\" " +
                "GROUP BY YEAR(Semestras_Stovejimo_laikas.stovejimo_pradzia), MONTH(Semestras_Stovejimo_laikas.stovejimo_pradzia), " +
                "DAY(Semestras_Stovejimo_laikas.stovejimo_pradzia), HOUR(Semestras_Stovejimo_laikas.stovejimo_pradzia) " +
                "ORDER BY laikas ASC", fromTime, currTime);

            CreateChart(query);
        }

        private void button_24h_Click(object sender, EventArgs e)
        {
            ButtonColorChange(button_24h);

            this.statChart.ChartAreas[0].AxisX.LabelStyle.Format = "HH:mm";
            fromTime = currTime.Add(new TimeSpan(-5,-24, 0, 0));

            query = String.Format("SELECT COUNT(Semestras_Stovejimo_laikas.id_Stovejimo_laikas) AS Kiekis, DATE_FORMAT(ANY_VALUE(Semestras_Stovejimo_laikas.stovejimo_pradzia), \"%y-%m-%d %h:%m\") AS laikas " +
                "FROM Semestras_Stovejimo_laikas " +
                "WHERE Semestras_Stovejimo_laikas.stovejimo_pradzia >= \"{0:yyyy-MM-dd HH:mm:ss}\" AND " +
                "Semestras_Stovejimo_laikas.stovejimo_pradzia <= \"{1:yyyy-MM-dd HH:mm:ss}\" " +
                "GROUP BY YEAR(Semestras_Stovejimo_laikas.stovejimo_pradzia), MONTH(Semestras_Stovejimo_laikas.stovejimo_pradzia), " +
                "DAY(Semestras_Stovejimo_laikas.stovejimo_pradzia), HOUR(Semestras_Stovejimo_laikas.stovejimo_pradzia) " +
                "ORDER BY laikas ASC", fromTime, currTime);

            CreateChart(query);
        }

        private void button_7d_Click(object sender, EventArgs e)
        {
            ButtonColorChange(button_7d);

            this.statChart.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy-MM-dd";
            fromTime = currTime.Add(new TimeSpan(-7, 0, 0, 0));

            query = String.Format("SELECT COUNT(Semestras_Stovejimo_laikas.id_Stovejimo_laikas) AS Kiekis, DATE_FORMAT(ANY_VALUE(Semestras_Stovejimo_laikas.stovejimo_pradzia), \"%Y-%m-%d\") AS laikas " +
                "FROM Semestras_Stovejimo_laikas " +
                "WHERE Semestras_Stovejimo_laikas.stovejimo_pradzia >= \"{0:yyyy-MM-dd}\" AND " +
                "Semestras_Stovejimo_laikas.stovejimo_pradzia <= \"{1:yyyy-MM-dd}\" " +
                "GROUP BY laikas " +
                "ORDER BY laikas ASC", fromTime, currTime);

            CreateChart(query);
        }

        private void button_1m_Click(object sender, EventArgs e)
        {
            ButtonColorChange(button_1m);

            this.statChart.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy-MM-dd";
            fromTime = currTime.Add(new TimeSpan(-30, 0, 0, 0));

            query = String.Format("SELECT COUNT(Semestras_Stovejimo_laikas.id_Stovejimo_laikas) AS Kiekis, DATE_FORMAT(ANY_VALUE(Semestras_Stovejimo_laikas.stovejimo_pradzia), \"%Y-%m-%d\") AS laikas " +
                "FROM Semestras_Stovejimo_laikas " +
                "WHERE Semestras_Stovejimo_laikas.stovejimo_pradzia >= \"{0:yyyy-MM-dd}\" AND " +
                "Semestras_Stovejimo_laikas.stovejimo_pradzia <= \"{1:yyyy-MM-dd}\" " +
                "GROUP BY laikas " +
                "ORDER BY laikas ASC",fromTime,currTime);

            CreateChart(query);


        }

        private void button_1y_Click(object sender, EventArgs e)
        {
            ButtonColorChange(button_1y);

            this.statChart.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy-MM-dd";
            fromTime = currTime.Add(new TimeSpan(-365, 0, 0, 0));
            
            query = String.Format("SELECT COUNT(Semestras_Stovejimo_laikas.id_Stovejimo_laikas) AS Kiekis, DATE_FORMAT(ANY_VALUE(Semestras_Stovejimo_laikas.stovejimo_pradzia), \"%Y-%m-%d\") AS laikas " +
                "FROM Semestras_Stovejimo_laikas " +
                "WHERE Semestras_Stovejimo_laikas.stovejimo_pradzia >= \"{0:yyyy-MM-dd}\" AND " +
                "Semestras_Stovejimo_laikas.stovejimo_pradzia <= \"{1:yyyy-MM-dd}\" " +
                "GROUP BY laikas " +
                "ORDER BY laikas ASC", fromTime, currTime);

            CreateChart(query);
        }
        private void button_All_Click(object sender, EventArgs e)
        {
            ButtonColorChange(button_All);

            this.statChart.ChartAreas[0].AxisX.LabelStyle.Format = "yyyy-MM-dd";

            CreateChart(defaultQuery);
        }

        public void CreateChart(string query)
        {
       
            Database db = new Database();
            db.sqlConnect.Open();
          
            List<int> count = new List<int>();
            List<DateTime> data = new List<DateTime>();
            
            MySqlCommand cmd = new MySqlCommand(query, db.sqlConnect);
            MySqlDataReader dataReader = cmd.ExecuteReader();

            while (dataReader.Read())
            {
                count.Add (int.Parse(dataReader["Kiekis"].ToString()));
                data.Add(DateTime.Parse(dataReader["Laikas"].ToString()));
            }
                                  
            Series series = new Series("Auto");

            CreateChartDesign(series, data, count);

            db.sqlConnect.Close();
        }
        public void CreateChartDesign(Series series, List<DateTime> data, List<int> count)
        {
            var del = statChart.Series.FindByName(series.Name);
            statChart.Series.Remove(del);

            statChart.ChartAreas[0].AxisY.MajorGrid.Interval = 10;
            statChart.ChartAreas[0].AxisY.MajorTickMark.Interval = 10;
            series.Points.DataBindXY(data, count);
            statChart.Series.Add(series);
            statChart.Series[0].XValueType = ChartValueType.DateTime;
            statChart.Series[0].BorderWidth = 3;
            series.ChartType = SeriesChartType.Line;
        }
        public void ButtonColorChange(Button buttonPressed)
        {
            button_1h.BackColor = Color.DarkGray;
            button_24h.BackColor = Color.DarkGray;
            button_7d.BackColor = Color.DarkGray;
            button_1m.BackColor = Color.DarkGray;
            button_1y.BackColor = Color.DarkGray;
            button_All.BackColor = Color.DarkGray;

            buttonPressed.BackColor = Color.White;
        }
       
    }
}

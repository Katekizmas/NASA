﻿namespace NASA
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.database = new System.Windows.Forms.Button();
            this.userInfo = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.dafaultPanel = new System.Windows.Forms.Panel();
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.nasaLabel = new System.Windows.Forms.Label();
            this.ImonesList = new System.Windows.Forms.ComboBox();
            this.PadalinysList = new System.Windows.Forms.ComboBox();
            this.AikstelesList = new System.Windows.Forms.ComboBox();
            this.imoneLabel = new System.Windows.Forms.Label();
            this.padalinysLabel = new System.Windows.Forms.Label();
            this.aiksteleLabel = new System.Windows.Forms.Label();
            this.imoneLabelText = new System.Windows.Forms.Label();
            this.padalinysLabelText = new System.Windows.Forms.Label();
            this.aiksteleLabelText = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.dafaultPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.database);
            this.panel1.Controls.Add(this.userInfo);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 720);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 690);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Alpha v1.0";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button4.Location = new System.Drawing.Point(0, 429);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(200, 100);
            this.button4.TabIndex = 5;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button3.Location = new System.Drawing.Point(0, 323);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(200, 100);
            this.button3.TabIndex = 4;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // database
            // 
            this.database.FlatAppearance.BorderSize = 0;
            this.database.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.database.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.database.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.database.Location = new System.Drawing.Point(0, 217);
            this.database.Name = "database";
            this.database.Size = new System.Drawing.Size(200, 100);
            this.database.TabIndex = 3;
            this.database.Text = "Database";
            this.database.UseVisualStyleBackColor = true;
            this.database.Click += new System.EventHandler(this.database_Click);
            // 
            // userInfo
            // 
            this.userInfo.FlatAppearance.BorderSize = 0;
            this.userInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.userInfo.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userInfo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.userInfo.Location = new System.Drawing.Point(0, 111);
            this.userInfo.Name = "userInfo";
            this.userInfo.Size = new System.Drawing.Size(200, 100);
            this.userInfo.TabIndex = 2;
            this.userInfo.Text = "User info";
            this.userInfo.UseVisualStyleBackColor = true;
            this.userInfo.Click += new System.EventHandler(this.userInfo_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel2.Controls.Add(this.button6);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(200, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1080, 80);
            this.panel2.TabIndex = 1;
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(927, 13);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(50, 50);
            this.button6.TabIndex = 7;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(1022, 13);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(50, 50);
            this.button5.TabIndex = 6;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // dafaultPanel
            // 
            this.dafaultPanel.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.dafaultPanel.Controls.Add(this.aiksteleLabelText);
            this.dafaultPanel.Controls.Add(this.padalinysLabelText);
            this.dafaultPanel.Controls.Add(this.imoneLabelText);
            this.dafaultPanel.Controls.Add(this.aiksteleLabel);
            this.dafaultPanel.Controls.Add(this.padalinysLabel);
            this.dafaultPanel.Controls.Add(this.imoneLabel);
            this.dafaultPanel.Controls.Add(this.AikstelesList);
            this.dafaultPanel.Controls.Add(this.PadalinysList);
            this.dafaultPanel.Controls.Add(this.ImonesList);
            this.dafaultPanel.Controls.Add(this.dataGrid);
            this.dafaultPanel.Controls.Add(this.nasaLabel);
            this.dafaultPanel.Location = new System.Drawing.Point(200, 80);
            this.dafaultPanel.Name = "dafaultPanel";
            this.dafaultPanel.Size = new System.Drawing.Size(1080, 640);
            this.dafaultPanel.TabIndex = 2;
            // 
            // dataGrid
            // 
            this.dataGrid.AllowUserToOrderColumns = true;
            this.dataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(0, -3);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.Size = new System.Drawing.Size(1080, 640);
            this.dataGrid.TabIndex = 1;
            // 
            // nasaLabel
            // 
            this.nasaLabel.AutoSize = true;
            this.nasaLabel.Font = new System.Drawing.Font("Century Gothic", 63.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nasaLabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.nasaLabel.Location = new System.Drawing.Point(260, 260);
            this.nasaLabel.Name = "nasaLabel";
            this.nasaLabel.Size = new System.Drawing.Size(533, 101);
            this.nasaLabel.TabIndex = 0;
            this.nasaLabel.Text = "N A S A org.";
            // 
            // ImonesList
            // 
            this.ImonesList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ImonesList.FormattingEnabled = true;
            this.ImonesList.ItemHeight = 20;
            this.ImonesList.Location = new System.Drawing.Point(6, 3);
            this.ImonesList.Name = "ImonesList";
            this.ImonesList.Size = new System.Drawing.Size(262, 28);
            this.ImonesList.TabIndex = 2;
            this.ImonesList.Text = "Pasirinkti imone";
            this.ImonesList.SelectedIndexChanged += new System.EventHandler(this.ImonesList_SelectedIndexChanged);
            // 
            // PadalinysList
            // 
            this.PadalinysList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PadalinysList.FormattingEnabled = true;
            this.PadalinysList.ItemHeight = 20;
            this.PadalinysList.Location = new System.Drawing.Point(274, 3);
            this.PadalinysList.Name = "PadalinysList";
            this.PadalinysList.Size = new System.Drawing.Size(262, 28);
            this.PadalinysList.TabIndex = 3;
            this.PadalinysList.Text = "Pasirinkti padalini";
            this.PadalinysList.SelectedIndexChanged += new System.EventHandler(this.PadalinysList_SelectedIndexChanged);
            // 
            // AikstelesList
            // 
            this.AikstelesList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AikstelesList.FormattingEnabled = true;
            this.AikstelesList.ItemHeight = 20;
            this.AikstelesList.Location = new System.Drawing.Point(542, 3);
            this.AikstelesList.Name = "AikstelesList";
            this.AikstelesList.Size = new System.Drawing.Size(262, 28);
            this.AikstelesList.TabIndex = 4;
            this.AikstelesList.Text = "Pasirinkti aikstele";
            this.AikstelesList.SelectedIndexChanged += new System.EventHandler(this.AikstelesList_SelectedIndexChanged);
            // 
            // imoneLabel
            // 
            this.imoneLabel.AutoSize = true;
            this.imoneLabel.Location = new System.Drawing.Point(34, 186);
            this.imoneLabel.Name = "imoneLabel";
            this.imoneLabel.Size = new System.Drawing.Size(97, 13);
            this.imoneLabel.TabIndex = 5;
            this.imoneLabel.Text = "Imonės informacija:";
            // 
            // padalinysLabel
            // 
            this.padalinysLabel.AutoSize = true;
            this.padalinysLabel.Location = new System.Drawing.Point(34, 292);
            this.padalinysLabel.Name = "padalinysLabel";
            this.padalinysLabel.Size = new System.Drawing.Size(106, 13);
            this.padalinysLabel.TabIndex = 6;
            this.padalinysLabel.Text = "Padalinio informacija:";
            // 
            // aiksteleLabel
            // 
            this.aiksteleLabel.AutoSize = true;
            this.aiksteleLabel.Location = new System.Drawing.Point(34, 398);
            this.aiksteleLabel.Name = "aiksteleLabel";
            this.aiksteleLabel.Size = new System.Drawing.Size(105, 13);
            this.aiksteleLabel.TabIndex = 7;
            this.aiksteleLabel.Text = "Aikštelės informacija:";
            // 
            // imoneLabelText
            // 
            this.imoneLabelText.AutoSize = true;
            this.imoneLabelText.Location = new System.Drawing.Point(174, 186);
            this.imoneLabelText.Name = "imoneLabelText";
            this.imoneLabelText.Size = new System.Drawing.Size(94, 13);
            this.imoneLabelText.TabIndex = 8;
            this.imoneLabelText.Text = "Imonės informacija";
            // 
            // padalinysLabelText
            // 
            this.padalinysLabelText.AutoSize = true;
            this.padalinysLabelText.Location = new System.Drawing.Point(174, 292);
            this.padalinysLabelText.Name = "padalinysLabelText";
            this.padalinysLabelText.Size = new System.Drawing.Size(94, 13);
            this.padalinysLabelText.TabIndex = 9;
            this.padalinysLabelText.Text = "Imonės informacija";
            // 
            // aiksteleLabelText
            // 
            this.aiksteleLabelText.AutoSize = true;
            this.aiksteleLabelText.Location = new System.Drawing.Point(174, 398);
            this.aiksteleLabelText.Name = "aiksteleLabelText";
            this.aiksteleLabelText.Size = new System.Drawing.Size(94, 13);
            this.aiksteleLabelText.TabIndex = 10;
            this.aiksteleLabelText.Text = "Imonės informacija";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1280, 720);
            this.Controls.Add(this.dafaultPanel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NASA";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.dafaultPanel.ResumeLayout(false);
            this.dafaultPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button userInfo;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button database;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel dafaultPanel;
        private System.Windows.Forms.Label nasaLabel;
        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.ComboBox ImonesList;
        private System.Windows.Forms.ComboBox AikstelesList;
        private System.Windows.Forms.ComboBox PadalinysList;
        private System.Windows.Forms.Label aiksteleLabelText;
        private System.Windows.Forms.Label padalinysLabelText;
        private System.Windows.Forms.Label imoneLabelText;
        private System.Windows.Forms.Label aiksteleLabel;
        private System.Windows.Forms.Label padalinysLabel;
        private System.Windows.Forms.Label imoneLabel;
    }
}


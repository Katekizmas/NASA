﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NASA
{
    public partial class Form1 : Form
    {
        Database db;
        public Form1()
        {
            InitializeComponent();
            db = new Database();
            dataGrid.Hide();
            ImonesList.Hide();
            PadalinysList.Hide();
            AikstelesList.Hide();
            imoneLabel.Hide();
            imoneLabelText.Hide();
            padalinysLabel.Hide();
            padalinysLabelText.Hide();
            aiksteleLabel.Hide();
            aiksteleLabelText.Hide();

        }

       

        private void button5_Click(object sender, EventArgs e)
        {
            Settings sett = new Settings();
            sett.Show();
            button5.Enabled = false;
            
        }

        private void database_Click(object sender, EventArgs e)
        {

            //dataGrid.Show();
            //DataTable dataTable_Auto= new DataTable();



            //dataTable_Auto.Columns.Add("Numeris");
            //dataTable_Auto.Columns.Add("Busena");
            //dataTable_Auto.Columns.Add("Aisktele");            
            //dataTable_Auto.Columns.Add("Vietu skaicius");
            //dataGrid.DataSource = dataTable_Auto;

            //db.getAuto(dataTable_Auto);


            nasaLabel.Hide();
            ImonesList.Show();
            db.getImoneList(ImonesList);

        
           
        }

        private void userInfo_Click(object sender, EventArgs e)
        {
            dataGrid.Hide();
            ImonesList.Hide();
            PadalinysList.Hide();
            AikstelesList.Hide();
            //nasaLabel.Show();

            MokejimoForma forma = new MokejimoForma();
            forma.Show();
        }

        private void ImonesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            padalinysLabel.Hide();
            padalinysLabelText.Hide();
            aiksteleLabel.Hide();
            aiksteleLabelText.Hide();
            AikstelesList.Hide();
            PadalinysList.Text="-- Pasirinkite padalinį --";

            imoneLabel.Show();
            imoneLabelText.Text = (ImonesList.SelectedItem as Database.ComboboxItem).fullText;
            imoneLabelText.Show();

            PadalinysList.Show();
            object key =(ImonesList.SelectedItem as Database.ComboboxItem).Value;
           

            db.getPadalinysList(PadalinysList,key);
        }

        private void PadalinysList_SelectedIndexChanged(object sender, EventArgs e)
        {
            AikstelesList.Hide();
            AikstelesList.Text= "-- Pasirinkite aikštelę --";

            padalinysLabel.Show();
            padalinysLabelText.Text = (PadalinysList.SelectedItem as Database.ComboboxItem).fullText;
            padalinysLabelText.Show();

            AikstelesList.Show();
            object key = (PadalinysList.SelectedItem as Database.ComboboxItem).Value;

            db.getAiksteleList(AikstelesList,key);
        }

        private void AikstelesList_SelectedIndexChanged(object sender, EventArgs e)
        {
            aiksteleLabel.Show();
            aiksteleLabelText.Text = (AikstelesList.SelectedItem as Database.ComboboxItem).fullText;
            aiksteleLabelText.Show();
        }
    }
}

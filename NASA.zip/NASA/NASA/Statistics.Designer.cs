﻿namespace NASA
{
    partial class Statistics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            this.button_1h = new System.Windows.Forms.Button();
            this.button_24h = new System.Windows.Forms.Button();
            this.button_7d = new System.Windows.Forms.Button();
            this.button_1m = new System.Windows.Forms.Button();
            this.button_1y = new System.Windows.Forms.Button();
            this.statChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button_All = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.statChart)).BeginInit();
            this.SuspendLayout();
            // 
            // button_1h
            // 
            this.button_1h.BackColor = System.Drawing.Color.DarkGray;
            this.button_1h.Location = new System.Drawing.Point(40, 55);
            this.button_1h.Name = "button_1h";
            this.button_1h.Size = new System.Drawing.Size(60, 30);
            this.button_1h.TabIndex = 7;
            this.button_1h.Text = "1H";
            this.button_1h.UseVisualStyleBackColor = false;
            this.button_1h.Click += new System.EventHandler(this.button_1h_Click);
            // 
            // button_24h
            // 
            this.button_24h.BackColor = System.Drawing.Color.DarkGray;
            this.button_24h.Location = new System.Drawing.Point(106, 55);
            this.button_24h.Name = "button_24h";
            this.button_24h.Size = new System.Drawing.Size(60, 30);
            this.button_24h.TabIndex = 2;
            this.button_24h.Text = "24H";
            this.button_24h.UseVisualStyleBackColor = false;
            this.button_24h.Click += new System.EventHandler(this.button_24h_Click);
            // 
            // button_7d
            // 
            this.button_7d.BackColor = System.Drawing.Color.DarkGray;
            this.button_7d.Location = new System.Drawing.Point(172, 55);
            this.button_7d.Name = "button_7d";
            this.button_7d.Size = new System.Drawing.Size(60, 30);
            this.button_7d.TabIndex = 3;
            this.button_7d.Text = "7D";
            this.button_7d.UseVisualStyleBackColor = false;
            this.button_7d.Click += new System.EventHandler(this.button_7d_Click);
            // 
            // button_1m
            // 
            this.button_1m.BackColor = System.Drawing.Color.DarkGray;
            this.button_1m.Location = new System.Drawing.Point(238, 55);
            this.button_1m.Name = "button_1m";
            this.button_1m.Size = new System.Drawing.Size(60, 30);
            this.button_1m.TabIndex = 4;
            this.button_1m.Text = "1M";
            this.button_1m.UseVisualStyleBackColor = false;
            this.button_1m.Click += new System.EventHandler(this.button_1m_Click);
            // 
            // button_1y
            // 
            this.button_1y.BackColor = System.Drawing.Color.DarkGray;
            this.button_1y.Location = new System.Drawing.Point(304, 55);
            this.button_1y.Name = "button_1y";
            this.button_1y.Size = new System.Drawing.Size(60, 30);
            this.button_1y.TabIndex = 5;
            this.button_1y.Text = "1Y";
            this.button_1y.UseVisualStyleBackColor = false;
            this.button_1y.Click += new System.EventHandler(this.button_1y_Click);
            // 
            // statChart
            // 
            chartArea2.Name = "ChartArea1";
            this.statChart.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.statChart.Legends.Add(legend2);
            this.statChart.Location = new System.Drawing.Point(40, 211);
            this.statChart.Name = "statChart";
            this.statChart.Size = new System.Drawing.Size(1028, 417);
            this.statChart.TabIndex = 6;
            this.statChart.Text = "chart1";
            // 
            // button_All
            // 
            this.button_All.BackColor = System.Drawing.Color.DarkGray;
            this.button_All.Location = new System.Drawing.Point(370, 55);
            this.button_All.Name = "button_All";
            this.button_All.Size = new System.Drawing.Size(60, 30);
            this.button_All.TabIndex = 1;
            this.button_All.Text = "ALL";
            this.button_All.UseVisualStyleBackColor = false;
            this.button_All.Click += new System.EventHandler(this.button_All_Click);
            // 
            // Statistics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1080, 640);
            this.Controls.Add(this.button_All);
            this.Controls.Add(this.statChart);
            this.Controls.Add(this.button_1y);
            this.Controls.Add(this.button_1m);
            this.Controls.Add(this.button_7d);
            this.Controls.Add(this.button_24h);
            this.Controls.Add(this.button_1h);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Statistics";
            this.Text = "Statistics";
            ((System.ComponentModel.ISupportInitialize)(this.statChart)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button_1h;
        private System.Windows.Forms.Button button_24h;
        private System.Windows.Forms.Button button_7d;
        private System.Windows.Forms.Button button_1m;
        private System.Windows.Forms.Button button_1y;
        private System.Windows.Forms.DataVisualization.Charting.Chart statChart;
        private System.Windows.Forms.Button button_All;
    }
}
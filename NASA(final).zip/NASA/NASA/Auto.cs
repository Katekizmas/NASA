﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NASA
{
    public partial class Auto : Form
    {

        Database db;
        public Auto()
        {
            InitializeComponent();

            db = new Database();
            autoInfo_Label.Hide();
            autoInfo_Label2.Hide();
            autoInfo_Label3.Hide();


        }
       

        private void dataGrid_Auto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGrid_Auto.Rows[e.RowIndex];

                            
                    
                string adr = row.Cells["ADRESAS"].Value.ToString();
                string nr = row.Cells["NUMERIS"].Value.ToString();
                string bs = row.Cells["BŪSENA"].Value.ToString();

                autoInfo_Label.Text =  "Numeris:  "+nr;
                autoInfo_Label2.Text = "Būsena:   "+bs;
                autoInfo_Label3.Text = "Adresas:  "+adr;


                autoInfo_Label.Show();
                autoInfo_Label2.Show();
                autoInfo_Label3.Show();
            }
        }
        public void AutoGrid()
        {
            dataGrid_Auto.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 9.75F, FontStyle.Bold);

            DataTable dataTable_Auto = new DataTable();


            
            dataTable_Auto.Columns.Add("NUMERIS");
            dataTable_Auto.Columns.Add("BŪSENA");
            dataTable_Auto.Columns.Add("ADRESAS");
            dataTable_Auto.Columns.Add("ID");
            dataGrid_Auto.DataSource = dataTable_Auto;
            dataGrid_Auto.Columns["ID"].Visible = false;
            dataGrid_Auto.Columns["Adresas"].Visible = false;
            dataGrid_Auto.Columns["BŪSENA"].Visible = false;
            
            db.getAuto(dataTable_Auto, null);
        }


    }
}

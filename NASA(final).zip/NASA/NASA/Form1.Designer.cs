﻿namespace NASA
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonPress = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Autos = new System.Windows.Forms.Button();
            this.statistics = new System.Windows.Forms.Button();
            this.database = new System.Windows.Forms.Button();
            this.payment = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.defaultPanel = new System.Windows.Forms.Panel();
            this.aikstEmptyLabel2 = new System.Windows.Forms.Label();
            this.aikstEmptyLabel = new System.Windows.Forms.Label();
            this.dataGrid_Auto = new System.Windows.Forms.DataGridView();
            this.dataGrid_Aikst = new System.Windows.Forms.DataGridView();
            this.padalinysLabelText = new System.Windows.Forms.Label();
            this.imoneLabelText = new System.Windows.Forms.Label();
            this.padalinysLabel = new System.Windows.Forms.Label();
            this.imoneLabel = new System.Windows.Forms.Label();
            this.PadalinysList = new System.Windows.Forms.ComboBox();
            this.ImonesList = new System.Windows.Forms.ComboBox();
            this.nasaLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.defaultPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_Auto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_Aikst)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel1.Controls.Add(this.buttonPress);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Autos);
            this.panel1.Controls.Add(this.statistics);
            this.panel1.Controls.Add(this.database);
            this.panel1.Controls.Add(this.payment);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 720);
            this.panel1.TabIndex = 0;
            // 
            // buttonPress
            // 
            this.buttonPress.BackColor = System.Drawing.Color.White;
            this.buttonPress.Location = new System.Drawing.Point(195, 110);
            this.buttonPress.Name = "buttonPress";
            this.buttonPress.Size = new System.Drawing.Size(5, 100);
            this.buttonPress.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 690);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Beta v1.01";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Autos
            // 
            this.Autos.FlatAppearance.BorderSize = 0;
            this.Autos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Autos.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Autos.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Autos.Location = new System.Drawing.Point(0, 410);
            this.Autos.Name = "Autos";
            this.Autos.Size = new System.Drawing.Size(200, 100);
            this.Autos.TabIndex = 5;
            this.Autos.Text = "Auto";
            this.Autos.UseVisualStyleBackColor = true;
            this.Autos.Click += new System.EventHandler(this.button4_Click);
            // 
            // statistics
            // 
            this.statistics.FlatAppearance.BorderSize = 0;
            this.statistics.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.statistics.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statistics.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.statistics.Location = new System.Drawing.Point(0, 310);
            this.statistics.Name = "statistics";
            this.statistics.Size = new System.Drawing.Size(200, 100);
            this.statistics.TabIndex = 4;
            this.statistics.Text = "Statistics";
            this.statistics.UseVisualStyleBackColor = true;
            this.statistics.Click += new System.EventHandler(this.button3_Click);
            // 
            // database
            // 
            this.database.FlatAppearance.BorderSize = 0;
            this.database.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.database.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.database.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.database.Location = new System.Drawing.Point(0, 210);
            this.database.Name = "database";
            this.database.Size = new System.Drawing.Size(200, 100);
            this.database.TabIndex = 3;
            this.database.Text = "Database";
            this.database.UseVisualStyleBackColor = true;
            this.database.Click += new System.EventHandler(this.database_Click);
            // 
            // payment
            // 
            this.payment.FlatAppearance.BorderSize = 0;
            this.payment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.payment.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payment.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.payment.Location = new System.Drawing.Point(0, 110);
            this.payment.Name = "payment";
            this.payment.Size = new System.Drawing.Size(200, 100);
            this.payment.TabIndex = 2;
            this.payment.Text = "PAYMENT";
            this.payment.UseVisualStyleBackColor = true;
            this.payment.Click += new System.EventHandler(this.userInfo_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(13, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel2.Controls.Add(this.button6);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(200, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1080, 80);
            this.panel2.TabIndex = 1;
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(927, 13);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(50, 50);
            this.button6.TabIndex = 7;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(1022, 13);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(50, 50);
            this.button5.TabIndex = 6;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // defaultPanel
            // 
            this.defaultPanel.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.defaultPanel.Controls.Add(this.aikstEmptyLabel2);
            this.defaultPanel.Controls.Add(this.aikstEmptyLabel);
            this.defaultPanel.Controls.Add(this.dataGrid_Auto);
            this.defaultPanel.Controls.Add(this.dataGrid_Aikst);
            this.defaultPanel.Controls.Add(this.padalinysLabelText);
            this.defaultPanel.Controls.Add(this.imoneLabelText);
            this.defaultPanel.Controls.Add(this.padalinysLabel);
            this.defaultPanel.Controls.Add(this.imoneLabel);
            this.defaultPanel.Controls.Add(this.PadalinysList);
            this.defaultPanel.Controls.Add(this.ImonesList);
            this.defaultPanel.Controls.Add(this.nasaLabel);
            this.defaultPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.defaultPanel.Location = new System.Drawing.Point(200, 80);
            this.defaultPanel.Name = "defaultPanel";
            this.defaultPanel.Size = new System.Drawing.Size(1080, 640);
            this.defaultPanel.TabIndex = 2;
            // 
            // aikstEmptyLabel2
            // 
            this.aikstEmptyLabel2.AutoSize = true;
            this.aikstEmptyLabel2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aikstEmptyLabel2.Location = new System.Drawing.Point(564, 272);
            this.aikstEmptyLabel2.Name = "aikstEmptyLabel2";
            this.aikstEmptyLabel2.Size = new System.Drawing.Size(117, 22);
            this.aikstEmptyLabel2.TabIndex = 13;
            this.aikstEmptyLabel2.Text = "YRA TUŠČIA";
            // 
            // aikstEmptyLabel
            // 
            this.aikstEmptyLabel.AutoSize = true;
            this.aikstEmptyLabel.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aikstEmptyLabel.Location = new System.Drawing.Point(564, 220);
            this.aikstEmptyLabel.Name = "aikstEmptyLabel";
            this.aikstEmptyLabel.Size = new System.Drawing.Size(158, 22);
            this.aikstEmptyLabel.TabIndex = 12;
            this.aikstEmptyLabel.Text = "aikstEmptyLabel";
            // 
            // dataGrid_Auto
            // 
            this.dataGrid_Auto.AllowUserToOrderColumns = true;
            this.dataGrid_Auto.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGrid_Auto.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGrid_Auto.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dataGrid_Auto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGrid_Auto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGrid_Auto.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGrid_Auto.Location = new System.Drawing.Point(568, 193);
            this.dataGrid_Auto.Name = "dataGrid_Auto";
            this.dataGrid_Auto.Size = new System.Drawing.Size(510, 456);
            this.dataGrid_Auto.TabIndex = 11;
            this.dataGrid_Auto.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGrid_Auto_CellContentClick);
            // 
            // dataGrid_Aikst
            // 
            this.dataGrid_Aikst.AllowUserToOrderColumns = true;
            this.dataGrid_Aikst.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGrid_Aikst.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGrid_Aikst.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            this.dataGrid_Aikst.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGrid_Aikst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGrid_Aikst.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGrid_Aikst.Location = new System.Drawing.Point(0, 193);
            this.dataGrid_Aikst.Name = "dataGrid_Aikst";
            this.dataGrid_Aikst.Size = new System.Drawing.Size(510, 456);
            this.dataGrid_Aikst.TabIndex = 10;
            this.dataGrid_Aikst.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGrid_CellContentClick);
            // 
            // padalinysLabelText
            // 
            this.padalinysLabelText.AutoSize = true;
            this.padalinysLabelText.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.padalinysLabelText.Location = new System.Drawing.Point(273, 137);
            this.padalinysLabelText.Name = "padalinysLabelText";
            this.padalinysLabelText.Size = new System.Drawing.Size(198, 22);
            this.padalinysLabelText.TabIndex = 9;
            this.padalinysLabelText.Text = "Padalinio informacija";
            // 
            // imoneLabelText
            // 
            this.imoneLabelText.AutoSize = true;
            this.imoneLabelText.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.imoneLabelText.Location = new System.Drawing.Point(273, 73);
            this.imoneLabelText.Name = "imoneLabelText";
            this.imoneLabelText.Size = new System.Drawing.Size(180, 22);
            this.imoneLabelText.TabIndex = 8;
            this.imoneLabelText.Text = "Imonės informacija";
            // 
            // padalinysLabel
            // 
            this.padalinysLabel.AutoSize = true;
            this.padalinysLabel.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.padalinysLabel.Location = new System.Drawing.Point(6, 137);
            this.padalinysLabel.Name = "padalinysLabel";
            this.padalinysLabel.Size = new System.Drawing.Size(203, 22);
            this.padalinysLabel.TabIndex = 6;
            this.padalinysLabel.Text = "Padalinio informacija:";
            // 
            // imoneLabel
            // 
            this.imoneLabel.AutoSize = true;
            this.imoneLabel.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.imoneLabel.Location = new System.Drawing.Point(6, 73);
            this.imoneLabel.Name = "imoneLabel";
            this.imoneLabel.Size = new System.Drawing.Size(185, 22);
            this.imoneLabel.TabIndex = 5;
            this.imoneLabel.Text = "Imonės informacija:";
            // 
            // PadalinysList
            // 
            this.PadalinysList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.PadalinysList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PadalinysList.FormattingEnabled = true;
            this.PadalinysList.ItemHeight = 20;
            this.PadalinysList.Location = new System.Drawing.Point(568, 6);
            this.PadalinysList.Name = "PadalinysList";
            this.PadalinysList.Size = new System.Drawing.Size(500, 28);
            this.PadalinysList.TabIndex = 3;
            this.PadalinysList.Text = "Pasirinkite padalini";
            this.PadalinysList.SelectedIndexChanged += new System.EventHandler(this.PadalinysList_SelectedIndexChanged);
            // 
            // ImonesList
            // 
            this.ImonesList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ImonesList.FormattingEnabled = true;
            this.ImonesList.ItemHeight = 20;
            this.ImonesList.Location = new System.Drawing.Point(9, 6);
            this.ImonesList.Name = "ImonesList";
            this.ImonesList.Size = new System.Drawing.Size(500, 28);
            this.ImonesList.TabIndex = 2;
            this.ImonesList.Text = "Pasirinkti imone";
            this.ImonesList.SelectedIndexChanged += new System.EventHandler(this.ImonesList_SelectedIndexChanged);
            // 
            // nasaLabel
            // 
            this.nasaLabel.AutoSize = true;
            this.nasaLabel.Font = new System.Drawing.Font("Century Gothic", 63.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nasaLabel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.nasaLabel.Location = new System.Drawing.Point(260, 260);
            this.nasaLabel.Name = "nasaLabel";
            this.nasaLabel.Size = new System.Drawing.Size(533, 101);
            this.nasaLabel.TabIndex = 0;
            this.nasaLabel.Text = "N A S A org.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1280, 720);
            this.Controls.Add(this.defaultPanel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NASA";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.defaultPanel.ResumeLayout(false);
            this.defaultPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_Auto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_Aikst)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button payment;
        private System.Windows.Forms.Button Autos;
        private System.Windows.Forms.Button statistics;
        private System.Windows.Forms.Button database;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel defaultPanel;
        private System.Windows.Forms.Label nasaLabel;
        private System.Windows.Forms.ComboBox ImonesList;
        private System.Windows.Forms.ComboBox PadalinysList;
        private System.Windows.Forms.Label padalinysLabelText;
        private System.Windows.Forms.Label imoneLabelText;
        private System.Windows.Forms.Label padalinysLabel;
        private System.Windows.Forms.Label imoneLabel;
        private System.Windows.Forms.DataGridView dataGrid_Aikst;
        private System.Windows.Forms.Panel buttonPress;
        private System.Windows.Forms.DataGridView dataGrid_Auto;
        private System.Windows.Forms.Label aikstEmptyLabel2;
        private System.Windows.Forms.Label aikstEmptyLabel;
    }
}


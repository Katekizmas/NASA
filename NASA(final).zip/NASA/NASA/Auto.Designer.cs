﻿namespace NASA
{
    partial class Auto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGrid_Auto = new System.Windows.Forms.DataGridView();
            this.noDataLabel = new System.Windows.Forms.Label();
            this.autoInfo_Label = new System.Windows.Forms.Label();
            this.autoInfo_Label2 = new System.Windows.Forms.Label();
            this.autoInfo_Label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_Auto)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGrid_Auto
            // 
            this.dataGrid_Auto.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGrid_Auto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid_Auto.Location = new System.Drawing.Point(12, 130);
            this.dataGrid_Auto.Name = "dataGrid_Auto";
            this.dataGrid_Auto.Size = new System.Drawing.Size(496, 498);
            this.dataGrid_Auto.TabIndex = 0;
            this.dataGrid_Auto.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGrid_Auto_CellContentClick);
            // 
            // noDataLabel
            // 
            this.noDataLabel.AutoSize = true;
            this.noDataLabel.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.noDataLabel.ForeColor = System.Drawing.Color.Black;
            this.noDataLabel.Location = new System.Drawing.Point(12, 9);
            this.noDataLabel.Name = "noDataLabel";
            this.noDataLabel.Size = new System.Drawing.Size(405, 56);
            this.noDataLabel.TabIndex = 9;
            this.noDataLabel.Text = "Automobilių info";
            // 
            // autoInfo_Label
            // 
            this.autoInfo_Label.AutoSize = true;
            this.autoInfo_Label.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.autoInfo_Label.Location = new System.Drawing.Point(660, 130);
            this.autoInfo_Label.Name = "autoInfo_Label";
            this.autoInfo_Label.Size = new System.Drawing.Size(89, 22);
            this.autoInfo_Label.TabIndex = 13;
            this.autoInfo_Label.Text = "autoInfo";
            // 
            // autoInfo_Label2
            // 
            this.autoInfo_Label2.AutoSize = true;
            this.autoInfo_Label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.autoInfo_Label2.Location = new System.Drawing.Point(660, 195);
            this.autoInfo_Label2.Name = "autoInfo_Label2";
            this.autoInfo_Label2.Size = new System.Drawing.Size(89, 22);
            this.autoInfo_Label2.TabIndex = 14;
            this.autoInfo_Label2.Text = "autoInfo";
            // 
            // autoInfo_Label3
            // 
            this.autoInfo_Label3.AutoSize = true;
            this.autoInfo_Label3.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.autoInfo_Label3.Location = new System.Drawing.Point(660, 268);
            this.autoInfo_Label3.Name = "autoInfo_Label3";
            this.autoInfo_Label3.Size = new System.Drawing.Size(89, 22);
            this.autoInfo_Label3.TabIndex = 15;
            this.autoInfo_Label3.Text = "autoInfo";
            // 
            // Auto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1080, 640);
            this.Controls.Add(this.autoInfo_Label3);
            this.Controls.Add(this.autoInfo_Label2);
            this.Controls.Add(this.autoInfo_Label);
            this.Controls.Add(this.noDataLabel);
            this.Controls.Add(this.dataGrid_Auto);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Auto";
            this.Text = "Auto";
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_Auto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGrid_Auto;
        private System.Windows.Forms.Label noDataLabel;
        private System.Windows.Forms.Label autoInfo_Label;
        private System.Windows.Forms.Label autoInfo_Label2;
        private System.Windows.Forms.Label autoInfo_Label3;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace NASA
{
    public class Database
    {
        //private string connStr;
        public MySqlConnection sqlConnect=new MySqlConnection();
        const string connStr = "SERVER=stud.if.ktu.lt; PORT=3306;DATABASE=domkel; UID=domkel;PASSWORD=queth8eiquo5Dah0;";

        private MySqlCommand cmd;
        private MySqlDataReader dataReader;

        MySqlConnectionStringBuilder conn_string = new MySqlConnectionStringBuilder();
        
        public Database()
        {
            conn_string.Server = "remotemysql.com";
            conn_string.UserID = "UST4tbdtjQ";
            conn_string.Password = "CMn3WAPDfR";
            conn_string.Database = "UST4tbdtjQ";
            conn_string.Port = 3306;
           
            sqlConnect.ConnectionString = conn_string.ToString();
            

        }

        public bool connected()
        {
            if (sqlConnect != null) return true;
            return false;
        }

        public void getAuto(DataTable autoTable)
        {
            sqlConnect.Open();
            autoTable.Clear();


            string query = "SELECT Semestras_Transporto_priemone.Numeris,Semestras_Transporto_priemone.Busena, " +
                "Semestras_Aikstele.Adresas, Semestras_Aikstele.Vietu_skaicius FROM Semestras_Transporto_priemone " +
                "INNER JOIN Semestras_Aikstele ON Semestras_Aikstele.id_Aikstele = Semestras_Transporto_priemone.fk_Aikstele";
            cmd = new MySqlCommand(query, sqlConnect);
            
            dataReader = cmd.ExecuteReader();
            //List<string> data = new List<string>();
            while (dataReader.Read())
            {

                //data.Add(dataReader["numeris"].ToString());
                string nr = dataReader["Numeris"].ToString();
                string busena = dataReader["Busena"].ToString();
                string adresas = dataReader["Adresas"].ToString();
                string aikstele_viet_sk = dataReader["Vietu_skaicius"].ToString();
                //string stovLaikas = dataReader["fk_Stovejimo_laikas"].ToString();
                autoTable.Rows.Add(new object[] { nr, busena, adresas, aikstele_viet_sk });
            }
            sqlConnect.Close();
           
        }
       
    }
}

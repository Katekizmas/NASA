﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NASA
{
    public partial class Form1 : Form
    {
        Database db;
        public Form1()
        {
            InitializeComponent();
            db = new Database();
            dataGrid.Hide();

        }

       

        private void button5_Click(object sender, EventArgs e)
        {
            Settings sett = new Settings();
            sett.Show();
            button5.Enabled = false;
            
        }

        private void database_Click(object sender, EventArgs e)
        {
            dataGrid.Show();
            DataTable dataTable_Auto= new DataTable();

           

            dataTable_Auto.Columns.Add("Numeris");
            dataTable_Auto.Columns.Add("Busena");
            dataTable_Auto.Columns.Add("Aisktele");            
            dataTable_Auto.Columns.Add("Vietu skaicius");
            dataGrid.DataSource = dataTable_Auto;

            db.getAuto(dataTable_Auto);

            //foreach (string nr in db.getData())
            //    MessageBox.Show(nr);
        }

        private void userInfo_Click(object sender, EventArgs e)
        {
            dataGrid.Hide();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NASA
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            regBar.Hide();
            regPanel.Hide();
            logPanel.Show();
        }

        private void log_Click(object sender, EventArgs e)
        {
            regBar.Hide();
            logBar.Show();

            regPanel.Hide();
            logPanel.Show();
        }

        private void reg_Click(object sender, EventArgs e)
        {
            regBar.Show();
            logBar.Hide();

            regPanel.Show();
            


            
            

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}

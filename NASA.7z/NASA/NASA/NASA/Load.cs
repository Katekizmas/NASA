﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NASA
{
    public partial class Load : Form
    {
        public Load()
        {
            InitializeComponent();
            this.timer1.Start();
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {
           
        }
        

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            progressBar1.Increment(4);
            if (progressBar1.Value == progressBar1.Maximum)
            {
                Form1 App = new Form1();
                timer1.Stop();
                this.Hide();
                Form1 log = new Form1();               
                log.Show();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
